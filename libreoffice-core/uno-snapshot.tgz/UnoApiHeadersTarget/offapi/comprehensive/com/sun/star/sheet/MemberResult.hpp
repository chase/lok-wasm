#ifndef INCLUDED_COM_SUN_STAR_SHEET_MEMBERRESULT_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_MEMBERRESULT_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/MemberResult.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline MemberResult::MemberResult()
    : Name()
    , Caption()
    , Flags(0)
    , Value(0)
{
}

inline MemberResult::MemberResult(const ::rtl::OUString& Name_, const ::rtl::OUString& Caption_, const ::sal_Int32& Flags_, const double& Value_)
    : Name(Name_)
    , Caption(Caption_)
    , Flags(Flags_)
    , Value(Value_)
{
}


inline bool operator==(const MemberResult& the_lhs, const MemberResult& the_rhs)
{
    return the_lhs.Name == the_rhs.Name
        && the_lhs.Caption == the_rhs.Caption
        && the_lhs.Flags == the_rhs.Flags
        && the_lhs.Value == the_rhs.Value;
}

inline bool operator!=(const MemberResult& the_lhs, const MemberResult& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theMemberResultType : public rtl::StaticWithInit< ::css::uno::Type *, theMemberResultType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.MemberResult" );
        ::rtl::OUString the_tname0( "string" );
        ::rtl::OUString the_name0( "Name" );
        ::rtl::OUString the_name1( "Caption" );
        ::rtl::OUString the_tname1( "long" );
        ::rtl::OUString the_name2( "Flags" );
        ::rtl::OUString the_tname2( "double" );
        ::rtl::OUString the_name3( "Value" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name1.pData }, false },
            { { typelib_TypeClass_LONG, the_tname1.pData, the_name2.pData }, false },
            { { typelib_TypeClass_DOUBLE, the_tname2.pData, the_name3.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 4, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::MemberResult const *) {
    return *detail::theMemberResultType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::MemberResult const *) {
    return ::cppu::UnoType< ::css::sheet::MemberResult >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_MEMBERRESULT_HPP
