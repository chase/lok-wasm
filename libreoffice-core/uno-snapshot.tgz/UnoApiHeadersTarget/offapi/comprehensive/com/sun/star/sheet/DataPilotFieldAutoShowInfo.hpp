#ifndef INCLUDED_COM_SUN_STAR_SHEET_DATAPILOTFIELDAUTOSHOWINFO_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_DATAPILOTFIELDAUTOSHOWINFO_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/DataPilotFieldAutoShowInfo.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline DataPilotFieldAutoShowInfo::DataPilotFieldAutoShowInfo()
    : IsEnabled(false)
    , ShowItemsMode(0)
    , ItemCount(0)
    , DataField()
{
}

inline DataPilotFieldAutoShowInfo::DataPilotFieldAutoShowInfo(const ::sal_Bool& IsEnabled_, const ::sal_Int32& ShowItemsMode_, const ::sal_Int32& ItemCount_, const ::rtl::OUString& DataField_)
    : IsEnabled(IsEnabled_)
    , ShowItemsMode(ShowItemsMode_)
    , ItemCount(ItemCount_)
    , DataField(DataField_)
{
}


inline bool operator==(const DataPilotFieldAutoShowInfo& the_lhs, const DataPilotFieldAutoShowInfo& the_rhs)
{
    return the_lhs.IsEnabled == the_rhs.IsEnabled
        && the_lhs.ShowItemsMode == the_rhs.ShowItemsMode
        && the_lhs.ItemCount == the_rhs.ItemCount
        && the_lhs.DataField == the_rhs.DataField;
}

inline bool operator!=(const DataPilotFieldAutoShowInfo& the_lhs, const DataPilotFieldAutoShowInfo& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theDataPilotFieldAutoShowInfoType : public rtl::StaticWithInit< ::css::uno::Type *, theDataPilotFieldAutoShowInfoType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.DataPilotFieldAutoShowInfo" );
        ::rtl::OUString the_tname0( "boolean" );
        ::rtl::OUString the_name0( "IsEnabled" );
        ::rtl::OUString the_tname1( "long" );
        ::rtl::OUString the_name1( "ShowItemsMode" );
        ::rtl::OUString the_name2( "ItemCount" );
        ::rtl::OUString the_tname2( "string" );
        ::rtl::OUString the_name3( "DataField" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_BOOLEAN, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_LONG, the_tname1.pData, the_name1.pData }, false },
            { { typelib_TypeClass_LONG, the_tname1.pData, the_name2.pData }, false },
            { { typelib_TypeClass_STRING, the_tname2.pData, the_name3.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 4, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::DataPilotFieldAutoShowInfo const *) {
    return *detail::theDataPilotFieldAutoShowInfoType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::DataPilotFieldAutoShowInfo const *) {
    return ::cppu::UnoType< ::css::sheet::DataPilotFieldAutoShowInfo >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_DATAPILOTFIELDAUTOSHOWINFO_HPP
