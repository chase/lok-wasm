#ifndef INCLUDED_COM_SUN_STAR_SHEET_FILTERFIELDVALUE_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_FILTERFIELDVALUE_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/FilterFieldValue.hdl"

#include "com/sun/star/util/Color.hpp"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline FilterFieldValue::FilterFieldValue()
    : IsNumeric(false)
    , NumericValue(0)
    , StringValue()
    , FilterType(0)
    , ColorValue(0)
{
}

inline FilterFieldValue::FilterFieldValue(const ::sal_Bool& IsNumeric_, const double& NumericValue_, const ::rtl::OUString& StringValue_, const ::sal_Int32& FilterType_, const ::sal_Int32& ColorValue_)
    : IsNumeric(IsNumeric_)
    , NumericValue(NumericValue_)
    , StringValue(StringValue_)
    , FilterType(FilterType_)
    , ColorValue(ColorValue_)
{
}


inline bool operator==(const FilterFieldValue& the_lhs, const FilterFieldValue& the_rhs)
{
    return the_lhs.IsNumeric == the_rhs.IsNumeric
        && the_lhs.NumericValue == the_rhs.NumericValue
        && the_lhs.StringValue == the_rhs.StringValue
        && the_lhs.FilterType == the_rhs.FilterType
        && the_lhs.ColorValue == the_rhs.ColorValue;
}

inline bool operator!=(const FilterFieldValue& the_lhs, const FilterFieldValue& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theFilterFieldValueType : public rtl::StaticWithInit< ::css::uno::Type *, theFilterFieldValueType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.FilterFieldValue" );
        ::rtl::OUString the_tname0( "boolean" );
        ::rtl::OUString the_name0( "IsNumeric" );
        ::rtl::OUString the_tname1( "double" );
        ::rtl::OUString the_name1( "NumericValue" );
        ::rtl::OUString the_tname2( "string" );
        ::rtl::OUString the_name2( "StringValue" );
        ::rtl::OUString the_tname3( "long" );
        ::rtl::OUString the_name3( "FilterType" );
        ::rtl::OUString the_tname4( "long" );
        ::rtl::OUString the_name4( "ColorValue" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_BOOLEAN, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_DOUBLE, the_tname1.pData, the_name1.pData }, false },
            { { typelib_TypeClass_STRING, the_tname2.pData, the_name2.pData }, false },
            { { typelib_TypeClass_LONG, the_tname3.pData, the_name3.pData }, false },
            { { typelib_TypeClass_LONG, the_tname4.pData, the_name4.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 5, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::FilterFieldValue const *) {
    return *detail::theFilterFieldValueType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::FilterFieldValue const *) {
    return ::cppu::UnoType< ::css::sheet::FilterFieldValue >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_FILTERFIELDVALUE_HPP
