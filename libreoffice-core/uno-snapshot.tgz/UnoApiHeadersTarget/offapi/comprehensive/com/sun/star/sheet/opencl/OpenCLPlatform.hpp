#ifndef INCLUDED_COM_SUN_STAR_SHEET_OPENCL_OPENCLPLATFORM_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_OPENCL_OPENCLPLATFORM_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/opencl/OpenCLPlatform.hdl"

#include "com/sun/star/sheet/opencl/OpenCLDevice.hpp"
#include "com/sun/star/uno/Sequence.hxx"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet { namespace opencl {

inline OpenCLPlatform::OpenCLPlatform()
    : Name()
    , Vendor()
    , Devices()
{
}

inline OpenCLPlatform::OpenCLPlatform(const ::rtl::OUString& Name_, const ::rtl::OUString& Vendor_, const ::css::uno::Sequence< ::css::sheet::opencl::OpenCLDevice >& Devices_)
    : Name(Name_)
    , Vendor(Vendor_)
    , Devices(Devices_)
{
}


inline bool operator==(const OpenCLPlatform& the_lhs, const OpenCLPlatform& the_rhs)
{
    return the_lhs.Name == the_rhs.Name
        && the_lhs.Vendor == the_rhs.Vendor
        && the_lhs.Devices == the_rhs.Devices;
}

inline bool operator!=(const OpenCLPlatform& the_lhs, const OpenCLPlatform& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace opencl { namespace detail {

struct theOpenCLPlatformType : public rtl::StaticWithInit< ::css::uno::Type *, theOpenCLPlatformType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.opencl.OpenCLPlatform" );
        ::rtl::OUString the_tname0( "string" );
        ::rtl::OUString the_name0( "Name" );
        ::rtl::OUString the_name1( "Vendor" );
        ::cppu::UnoType< ::cppu::UnoSequenceType< ::css::sheet::opencl::OpenCLDevice > >::get();
        ::rtl::OUString the_tname1( "[]com.sun.star.sheet.opencl.OpenCLDevice" );
        ::rtl::OUString the_name2( "Devices" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name1.pData }, false },
            { { typelib_TypeClass_SEQUENCE, the_tname1.pData, the_name2.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 3, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace opencl {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::opencl::OpenCLPlatform const *) {
    return *detail::theOpenCLPlatformType::get();
}

} } } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::opencl::OpenCLPlatform const *) {
    return ::cppu::UnoType< ::css::sheet::opencl::OpenCLPlatform >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_OPENCL_OPENCLPLATFORM_HPP
