#ifndef INCLUDED_COM_SUN_STAR_I18N_NATIVENUMBERXMLATTRIBUTES2_HPP
#define INCLUDED_COM_SUN_STAR_I18N_NATIVENUMBERXMLATTRIBUTES2_HPP

#include "sal/config.h"

#include "com/sun/star/i18n/NativeNumberXmlAttributes2.hdl"

#include "com/sun/star/i18n/NativeNumberXmlAttributes.hpp"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace i18n {

inline NativeNumberXmlAttributes2::NativeNumberXmlAttributes2()
    : ::css::i18n::NativeNumberXmlAttributes()
    , Spellout()
{
}

inline NativeNumberXmlAttributes2::NativeNumberXmlAttributes2(const ::css::lang::Locale& Locale_, const ::rtl::OUString& Format_, const ::rtl::OUString& Style_, const ::rtl::OUString& Spellout_)
    : ::css::i18n::NativeNumberXmlAttributes(Locale_, Format_, Style_)
    , Spellout(Spellout_)
{
}


inline bool operator==(const NativeNumberXmlAttributes2& the_lhs, const NativeNumberXmlAttributes2& the_rhs)
{
    return operator==( static_cast< ::css::i18n::NativeNumberXmlAttributes>(the_lhs), static_cast< ::css::i18n::NativeNumberXmlAttributes>(the_rhs) )

        && the_lhs.Spellout == the_rhs.Spellout;
}

inline bool operator!=(const NativeNumberXmlAttributes2& the_lhs, const NativeNumberXmlAttributes2& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace i18n { namespace detail {

struct theNativeNumberXmlAttributes2Type : public rtl::StaticWithInit< ::css::uno::Type *, theNativeNumberXmlAttributes2Type >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.i18n.NativeNumberXmlAttributes2" );
        ::rtl::OUString the_tname0( "string" );
        ::rtl::OUString the_name0( "Spellout" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name0.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, ::cppu::UnoType< ::css::i18n::NativeNumberXmlAttributes >::get().getTypeLibType(), 1, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace i18n {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::i18n::NativeNumberXmlAttributes2 const *) {
    return *detail::theNativeNumberXmlAttributes2Type::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::i18n::NativeNumberXmlAttributes2 const *) {
    return ::cppu::UnoType< ::css::i18n::NativeNumberXmlAttributes2 >::get();
}

#endif // INCLUDED_COM_SUN_STAR_I18N_NATIVENUMBERXMLATTRIBUTES2_HPP
