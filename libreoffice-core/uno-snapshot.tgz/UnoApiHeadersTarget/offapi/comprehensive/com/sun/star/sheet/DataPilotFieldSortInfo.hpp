#ifndef INCLUDED_COM_SUN_STAR_SHEET_DATAPILOTFIELDSORTINFO_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_DATAPILOTFIELDSORTINFO_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/DataPilotFieldSortInfo.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline DataPilotFieldSortInfo::DataPilotFieldSortInfo()
    : Field()
    , IsAscending(false)
    , Mode(0)
{
}

inline DataPilotFieldSortInfo::DataPilotFieldSortInfo(const ::rtl::OUString& Field_, const ::sal_Bool& IsAscending_, const ::sal_Int32& Mode_)
    : Field(Field_)
    , IsAscending(IsAscending_)
    , Mode(Mode_)
{
}


inline bool operator==(const DataPilotFieldSortInfo& the_lhs, const DataPilotFieldSortInfo& the_rhs)
{
    return the_lhs.Field == the_rhs.Field
        && the_lhs.IsAscending == the_rhs.IsAscending
        && the_lhs.Mode == the_rhs.Mode;
}

inline bool operator!=(const DataPilotFieldSortInfo& the_lhs, const DataPilotFieldSortInfo& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theDataPilotFieldSortInfoType : public rtl::StaticWithInit< ::css::uno::Type *, theDataPilotFieldSortInfoType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.DataPilotFieldSortInfo" );
        ::rtl::OUString the_tname0( "string" );
        ::rtl::OUString the_name0( "Field" );
        ::rtl::OUString the_tname1( "boolean" );
        ::rtl::OUString the_name1( "IsAscending" );
        ::rtl::OUString the_tname2( "long" );
        ::rtl::OUString the_name2( "Mode" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_BOOLEAN, the_tname1.pData, the_name1.pData }, false },
            { { typelib_TypeClass_LONG, the_tname2.pData, the_name2.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 3, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::DataPilotFieldSortInfo const *) {
    return *detail::theDataPilotFieldSortInfoType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::DataPilotFieldSortInfo const *) {
    return ::cppu::UnoType< ::css::sheet::DataPilotFieldSortInfo >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_DATAPILOTFIELDSORTINFO_HPP
