#ifndef INCLUDED_COM_SUN_STAR_SHEET_NAMETOKEN_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_NAMETOKEN_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/NameToken.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline NameToken::NameToken()
    : Index(0)
    , Sheet(0)
{
}

inline NameToken::NameToken(const ::sal_Int32& Index_, const ::sal_Int32& Sheet_)
    : Index(Index_)
    , Sheet(Sheet_)
{
}


inline bool operator==(const NameToken& the_lhs, const NameToken& the_rhs)
{
    return the_lhs.Index == the_rhs.Index
        && the_lhs.Sheet == the_rhs.Sheet;
}

inline bool operator!=(const NameToken& the_lhs, const NameToken& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theNameTokenType : public rtl::StaticWithInit< ::css::uno::Type *, theNameTokenType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.NameToken" );
        ::rtl::OUString the_tname0( "long" );
        ::rtl::OUString the_name0( "Index" );
        ::rtl::OUString the_name1( "Sheet" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name1.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 2, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::NameToken const *) {
    return *detail::theNameTokenType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::NameToken const *) {
    return ::cppu::UnoType< ::css::sheet::NameToken >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_NAMETOKEN_HPP
