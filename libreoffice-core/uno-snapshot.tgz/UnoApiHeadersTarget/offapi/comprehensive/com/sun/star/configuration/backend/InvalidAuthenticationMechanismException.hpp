#ifndef INCLUDED_COM_SUN_STAR_CONFIGURATION_BACKEND_INVALIDAUTHENTICATIONMECHANISMEXCEPTION_HPP
#define INCLUDED_COM_SUN_STAR_CONFIGURATION_BACKEND_INVALIDAUTHENTICATIONMECHANISMEXCEPTION_HPP

#include "sal/config.h"

#include "com/sun/star/configuration/backend/InvalidAuthenticationMechanismException.hdl"

#include "com/sun/star/configuration/backend/BackendSetupException.hpp"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/instance.hxx"

namespace com { namespace sun { namespace star { namespace configuration { namespace backend {

inline InvalidAuthenticationMechanismException::InvalidAuthenticationMechanismException(
#if defined LIBO_USE_SOURCE_LOCATION
    LIBO_USE_SOURCE_LOCATION::source_location location
#endif
    )
    : ::css::configuration::backend::BackendSetupException(
#if defined LIBO_USE_SOURCE_LOCATION
    location
#endif
)
{
    ::cppu::UnoType< ::css::configuration::backend::InvalidAuthenticationMechanismException >::get();
}

inline InvalidAuthenticationMechanismException::InvalidAuthenticationMechanismException(const ::rtl::OUString& Message_, const ::css::uno::Reference< ::css::uno::XInterface >& Context_, const ::css::uno::Any& BackendException_
#if defined LIBO_USE_SOURCE_LOCATION
    , LIBO_USE_SOURCE_LOCATION::source_location location
#endif
)
    : ::css::configuration::backend::BackendSetupException(Message_, Context_, BackendException_
#if defined LIBO_USE_SOURCE_LOCATION
    , location
#endif
)
{
    ::cppu::UnoType< ::css::configuration::backend::InvalidAuthenticationMechanismException >::get();
}

#if !defined LIBO_INTERNAL_ONLY
InvalidAuthenticationMechanismException::InvalidAuthenticationMechanismException(InvalidAuthenticationMechanismException const & the_other): ::css::configuration::backend::BackendSetupException(the_other) {}

InvalidAuthenticationMechanismException::~InvalidAuthenticationMechanismException() {}

InvalidAuthenticationMechanismException & InvalidAuthenticationMechanismException::operator =(InvalidAuthenticationMechanismException const & the_other) {
    //TODO: Just like its implicitly-defined counterpart, this function definition is not exception-safe
    ::css::configuration::backend::BackendSetupException::operator =(the_other);
    return *this;
}
#endif

} } } } }

namespace com { namespace sun { namespace star { namespace configuration { namespace backend { namespace detail {

struct theInvalidAuthenticationMechanismExceptionType : public rtl::StaticWithInit< ::css::uno::Type *, theInvalidAuthenticationMechanismExceptionType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString sTypeName( "com.sun.star.configuration.backend.InvalidAuthenticationMechanismException" );

        // Start inline typedescription generation
        typelib_TypeDescription * pTD = 0;
        const ::css::uno::Type& rSuperType = ::cppu::UnoType< ::css::configuration::backend::BackendSetupException >::get();

        typelib_typedescription_new(
            &pTD,
            (typelib_TypeClass)::css::uno::TypeClass_EXCEPTION, sTypeName.pData,
            rSuperType.getTypeLibType(),
            0,
            0 );

        typelib_typedescription_register( (typelib_TypeDescription**)&pTD );

        typelib_typedescription_release( pTD );
        // End inline typedescription generation

        return new ::css::uno::Type( ::css::uno::TypeClass_EXCEPTION, sTypeName ); // leaked
    }
};

} } } } } }

namespace com { namespace sun { namespace star { namespace configuration { namespace backend {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::configuration::backend::InvalidAuthenticationMechanismException const *) {
    return *detail::theInvalidAuthenticationMechanismExceptionType::get();
}

} } } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::configuration::backend::InvalidAuthenticationMechanismException const *) {
    return ::cppu::UnoType< ::css::configuration::backend::InvalidAuthenticationMechanismException >::get();
}

#endif // INCLUDED_COM_SUN_STAR_CONFIGURATION_BACKEND_INVALIDAUTHENTICATIONMECHANISMEXCEPTION_HPP
