#ifndef INCLUDED_COM_SUN_STAR_SHEET_SINGLEREFERENCE_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_SINGLEREFERENCE_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/SingleReference.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline SingleReference::SingleReference()
    : Column(0)
    , RelativeColumn(0)
    , Row(0)
    , RelativeRow(0)
    , Sheet(0)
    , RelativeSheet(0)
    , Flags(0)
{
}

inline SingleReference::SingleReference(const ::sal_Int32& Column_, const ::sal_Int32& RelativeColumn_, const ::sal_Int32& Row_, const ::sal_Int32& RelativeRow_, const ::sal_Int32& Sheet_, const ::sal_Int32& RelativeSheet_, const ::sal_Int32& Flags_)
    : Column(Column_)
    , RelativeColumn(RelativeColumn_)
    , Row(Row_)
    , RelativeRow(RelativeRow_)
    , Sheet(Sheet_)
    , RelativeSheet(RelativeSheet_)
    , Flags(Flags_)
{
}


inline bool operator==(const SingleReference& the_lhs, const SingleReference& the_rhs)
{
    return the_lhs.Column == the_rhs.Column
        && the_lhs.RelativeColumn == the_rhs.RelativeColumn
        && the_lhs.Row == the_rhs.Row
        && the_lhs.RelativeRow == the_rhs.RelativeRow
        && the_lhs.Sheet == the_rhs.Sheet
        && the_lhs.RelativeSheet == the_rhs.RelativeSheet
        && the_lhs.Flags == the_rhs.Flags;
}

inline bool operator!=(const SingleReference& the_lhs, const SingleReference& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theSingleReferenceType : public rtl::StaticWithInit< ::css::uno::Type *, theSingleReferenceType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.SingleReference" );
        ::rtl::OUString the_tname0( "long" );
        ::rtl::OUString the_name0( "Column" );
        ::rtl::OUString the_name1( "RelativeColumn" );
        ::rtl::OUString the_name2( "Row" );
        ::rtl::OUString the_name3( "RelativeRow" );
        ::rtl::OUString the_name4( "Sheet" );
        ::rtl::OUString the_name5( "RelativeSheet" );
        ::rtl::OUString the_name6( "Flags" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name1.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name2.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name3.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name4.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name5.pData }, false },
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name6.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 7, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::SingleReference const *) {
    return *detail::theSingleReferenceType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::SingleReference const *) {
    return ::cppu::UnoType< ::css::sheet::SingleReference >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_SINGLEREFERENCE_HPP
