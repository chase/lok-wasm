#ifndef INCLUDED_COM_SUN_STAR_I18N_CALENDARITEM_HPP
#define INCLUDED_COM_SUN_STAR_I18N_CALENDARITEM_HPP

#include "sal/config.h"

#include "com/sun/star/i18n/CalendarItem.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace i18n {

inline CalendarItem::CalendarItem()
    : ID()
    , AbbrevName()
    , FullName()
{
}

inline CalendarItem::CalendarItem(const ::rtl::OUString& ID_, const ::rtl::OUString& AbbrevName_, const ::rtl::OUString& FullName_)
    : ID(ID_)
    , AbbrevName(AbbrevName_)
    , FullName(FullName_)
{
}


inline bool operator==(const CalendarItem& the_lhs, const CalendarItem& the_rhs)
{
    return the_lhs.ID == the_rhs.ID
        && the_lhs.AbbrevName == the_rhs.AbbrevName
        && the_lhs.FullName == the_rhs.FullName;
}

inline bool operator!=(const CalendarItem& the_lhs, const CalendarItem& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace i18n { namespace detail {

struct theCalendarItemType : public rtl::StaticWithInit< ::css::uno::Type *, theCalendarItemType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.i18n.CalendarItem" );
        ::rtl::OUString the_tname0( "string" );
        ::rtl::OUString the_name0( "ID" );
        ::rtl::OUString the_name1( "AbbrevName" );
        ::rtl::OUString the_name2( "FullName" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name1.pData }, false },
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name2.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 3, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace i18n {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::i18n::CalendarItem const *) {
    return *detail::theCalendarItemType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::i18n::CalendarItem const *) {
    return ::cppu::UnoType< ::css::i18n::CalendarItem >::get();
}

#endif // INCLUDED_COM_SUN_STAR_I18N_CALENDARITEM_HPP
