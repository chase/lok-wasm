#ifndef INCLUDED_COM_SUN_STAR_SHEET_TABLEPAGEBREAKDATA_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_TABLEPAGEBREAKDATA_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/TablePageBreakData.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline TablePageBreakData::TablePageBreakData()
    : Position(0)
    , ManualBreak(false)
{
}

inline TablePageBreakData::TablePageBreakData(const ::sal_Int32& Position_, const ::sal_Bool& ManualBreak_)
    : Position(Position_)
    , ManualBreak(ManualBreak_)
{
}


inline bool operator==(const TablePageBreakData& the_lhs, const TablePageBreakData& the_rhs)
{
    return the_lhs.Position == the_rhs.Position
        && the_lhs.ManualBreak == the_rhs.ManualBreak;
}

inline bool operator!=(const TablePageBreakData& the_lhs, const TablePageBreakData& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theTablePageBreakDataType : public rtl::StaticWithInit< ::css::uno::Type *, theTablePageBreakDataType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.TablePageBreakData" );
        ::rtl::OUString the_tname0( "long" );
        ::rtl::OUString the_name0( "Position" );
        ::rtl::OUString the_tname1( "boolean" );
        ::rtl::OUString the_name1( "ManualBreak" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_BOOLEAN, the_tname1.pData, the_name1.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 2, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::TablePageBreakData const *) {
    return *detail::theTablePageBreakDataType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::TablePageBreakData const *) {
    return ::cppu::UnoType< ::css::sheet::TablePageBreakData >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_TABLEPAGEBREAKDATA_HPP
