#ifndef INCLUDED_COM_SUN_STAR_I18N_FORBIDDENCHARACTERS_HPP
#define INCLUDED_COM_SUN_STAR_I18N_FORBIDDENCHARACTERS_HPP

#include "sal/config.h"

#include "com/sun/star/i18n/ForbiddenCharacters.hdl"

#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace i18n {

inline ForbiddenCharacters::ForbiddenCharacters()
    : beginLine()
    , endLine()
{
}

inline ForbiddenCharacters::ForbiddenCharacters(const ::rtl::OUString& beginLine_, const ::rtl::OUString& endLine_)
    : beginLine(beginLine_)
    , endLine(endLine_)
{
}


inline bool operator==(const ForbiddenCharacters& the_lhs, const ForbiddenCharacters& the_rhs)
{
    return the_lhs.beginLine == the_rhs.beginLine
        && the_lhs.endLine == the_rhs.endLine;
}

inline bool operator!=(const ForbiddenCharacters& the_lhs, const ForbiddenCharacters& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace i18n { namespace detail {

struct theForbiddenCharactersType : public rtl::StaticWithInit< ::css::uno::Type *, theForbiddenCharactersType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.i18n.ForbiddenCharacters" );
        ::rtl::OUString the_tname0( "string" );
        ::rtl::OUString the_name0( "beginLine" );
        ::rtl::OUString the_name1( "endLine" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_STRING, the_tname0.pData, the_name1.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 2, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace i18n {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::i18n::ForbiddenCharacters const *) {
    return *detail::theForbiddenCharactersType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::i18n::ForbiddenCharacters const *) {
    return ::cppu::UnoType< ::css::i18n::ForbiddenCharacters >::get();
}

#endif // INCLUDED_COM_SUN_STAR_I18N_FORBIDDENCHARACTERS_HPP
