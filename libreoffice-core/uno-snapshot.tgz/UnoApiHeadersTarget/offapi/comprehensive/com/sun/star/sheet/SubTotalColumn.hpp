#ifndef INCLUDED_COM_SUN_STAR_SHEET_SUBTOTALCOLUMN_HPP
#define INCLUDED_COM_SUN_STAR_SHEET_SUBTOTALCOLUMN_HPP

#include "sal/config.h"

#include "com/sun/star/sheet/SubTotalColumn.hdl"

#include "com/sun/star/sheet/GeneralFunction.hpp"
#include "com/sun/star/uno/Type.hxx"
#include "cppu/unotype.hxx"
#include "rtl/ustring.h"
#include "rtl/ustring.hxx"
#include "rtl/instance.hxx"
#include "sal/types.h"
#include "typelib/typeclass.h"
#include "typelib/typedescription.h"

namespace com { namespace sun { namespace star { namespace sheet {

inline SubTotalColumn::SubTotalColumn()
    : Column(0)
    , Function(::css::sheet::GeneralFunction_NONE)
{
}

inline SubTotalColumn::SubTotalColumn(const ::sal_Int32& Column_, const ::css::sheet::GeneralFunction& Function_)
    : Column(Column_)
    , Function(Function_)
{
}


inline bool operator==(const SubTotalColumn& the_lhs, const SubTotalColumn& the_rhs)
{
    return the_lhs.Column == the_rhs.Column
        && the_lhs.Function == the_rhs.Function;
}

inline bool operator!=(const SubTotalColumn& the_lhs, const SubTotalColumn& the_rhs)
{
return !operator==(the_lhs, the_rhs);
}
} } } }

namespace com { namespace sun { namespace star { namespace sheet { namespace detail {

struct theSubTotalColumnType : public rtl::StaticWithInit< ::css::uno::Type *, theSubTotalColumnType >
{
    ::css::uno::Type * operator()() const
    {
        ::rtl::OUString the_name( "com.sun.star.sheet.SubTotalColumn" );
        ::rtl::OUString the_tname0( "long" );
        ::rtl::OUString the_name0( "Column" );
        ::cppu::UnoType< ::css::sheet::GeneralFunction >::get();
        ::rtl::OUString the_tname1( "com.sun.star.sheet.GeneralFunction" );
        ::rtl::OUString the_name1( "Function" );
        ::typelib_StructMember_Init the_members[] = {
            { { typelib_TypeClass_LONG, the_tname0.pData, the_name0.pData }, false },
            { { typelib_TypeClass_ENUM, the_tname1.pData, the_name1.pData }, false } };
        ::typelib_TypeDescription * the_newType = 0;
        ::typelib_typedescription_newStruct(&the_newType, the_name.pData, 0, 2, the_members);
        ::typelib_typedescription_register(&the_newType);
        ::typelib_typedescription_release(the_newType);
        return new ::css::uno::Type(::css::uno::TypeClass_STRUCT, the_name); // leaked
    }
};
} } } } }

namespace com { namespace sun { namespace star { namespace sheet {

inline ::css::uno::Type const & cppu_detail_getUnoType(SAL_UNUSED_PARAMETER ::css::sheet::SubTotalColumn const *) {
    return *detail::theSubTotalColumnType::get();
}

} } } }

SAL_DEPRECATED("use cppu::UnoType") inline ::css::uno::Type const & SAL_CALL getCppuType(SAL_UNUSED_PARAMETER ::css::sheet::SubTotalColumn const *) {
    return ::cppu::UnoType< ::css::sheet::SubTotalColumn >::get();
}

#endif // INCLUDED_COM_SUN_STAR_SHEET_SUBTOTALCOLUMN_HPP
